# 实验报告 · Monitor 修复（v2）与 File 标签审计 · 2026-11-11

更新：2026-11-11 00:15（Asia/Shanghai，UTC+8）。状态：**CPU 部分已完成**；monitor v2 的 GPU 推理部分已排进链 `scripts/run_tf_sweep_20261111.sh`，链在等待显卡空闲（启动时显卡被用户的游戏占用，约 7.3GB / 90%）。v2 的数字跑完后自动写入 `runs_ext_monitor/report.md` 和 `monitor_eval.json`，本报告第 4 节届时补数。

## 1. 一句话结论

1. **Round 2 的 File last-match 标签有错**：题目要求“返回最后一行”，标签却是整个匹配列表。模型按题意答对会被判错。所以“File 遗忘 / File 不迁移”主要是判分造成的假象。
2. **旧 monitor 并没有漏掉阶段内遗忘**：在所有阶段内真实掉分里，v1（任何下降就触发）召回 1.0、误报 0.10~0.25。它漏掉的是**阶段开始前就已经不会的技能**（地板效应，例如 A 场景 Database filter-top 起点只有 0.00~0.03），而这正是 targeted 复习收益最大的地方。
3. 修复办法是改判定规则，而不是只加题：v2 规则加入“水平低于胜任线”（DEFICIENT）和“证据不足”（INSUFFICIENT_EVIDENCE）。在同一批旧探针上，对“需要复习”的召回从 0.36 提到 0.82（IE 计为触发时为 1.00），误报 2/4。

## 2. File 标签审计（CPU，只读重判分）

- 位置：`data_round2/{monitor,final}/file.jsonl` 与 `pool/file.jsonl` 中的 16 条 target 行。`round2_data._target_file` 先算出 `answer = matches[-1]["text"]`，但 `_make_row` 用 `answer_spec identity` 重新计算，结果是整个列表。历史测试 `data_phase2/file/test.jsonl` 的 file_last_match 用的是 `match index -1`，也就是最后一行，两套口径互相矛盾。
- 重判分规则（`fac_tinyagent/ext_rescore.py`）：工具、参数、执行三项照旧；答案判对的条件是：等于最后一行原文；或者是只含这一行的单元素列表/字典且行号对；或者行号对、去掉 “line N: ” 前缀后的正文一致。整个列表判错。原始 `results.jsonl` 不改。
- Round 2 natural final，旧工具宏平均联合成功率（3 个种子的均值）：

| 场景 | 方法 | 原标签 | 修正标签 | File 修正（逐种子） |
|---|---|---:|---:|---|
| A | start | 0.481 | 0.407 | 0.133 / 0.133 / 0.400 |
| A | none | 0.211 | 0.341 | 0.067 / 0.433 / 0.667 |
| A | uniform | 0.204 | 0.352 | 0.333 / 0.267 / 0.733 |
| A | fixed targeted | 0.641 | **0.822** | 0.833 / 0.333 / 0.467 |
| A | adaptive | 0.363 | 0.500 | 0.733 / 0.033 / 0.500 |
| C | start | 0.144 | 0.539 | 0.767 / 0.800 / 0.800 |
| C | none | 0.167 | 0.511 | 0.833 / 0.400 / 0.833 |
| C | uniform | 0.306 | 0.600 | 0.833 / 0.233 / 0.700 |
| C | fixed targeted | 0.528 | **0.639** | 0.267 / 0.367 / 0.200 |
| C | adaptive | 0.306 | 0.600 | 0.800 / 0.233 / 0.733 |

解读：A 场景里 targeted 相对 uniform 的优势更大了（+0.47）；C 场景里优势只剩 +0.04，因为错误标签的 File target 行在 C 里反而把 File 拉低。C 的起点模型按题意其实大多能做对 File（约 0.79），原来报告的 0 是假象。

## 3. Monitor 验证设置

- 单元：场景 × 种子 × 旧工具，A 9 个、C 6 个，共 15 个。
- 在线设定：监测只看阶段起点和中点，要预测“不复习时（none 分支）阶段结束时该工具是否需要帮助”。
- 金标准来自独立 natural final（30 题/工具，修正判分）：
  - G_drop：end_none ≤ start − 0.10（阶段内遗忘）
  - G_need：end_none < 0.80（需要复习）
  - G_cum：end_none ≤ ref − 0.10，ref 是该工具刚学完那一阶段的 checkpoint（累积遗忘；需要 GPU 补测 ref，目前只有 ref = 起点的 6 个单元可算）
- 检测器：
  - V1：Round 2 原规则，起点到中点任何下降就触发。
  - rule2：`fac_tinyagent/monitor_v2.py`，DEGRADED 要求下降 ≥0.10 且单侧两比例检验 p<0.10；DEFICIENT 要求 90% Wilson 上界 < τ=0.8；IE 在题数 <8、下降不显著、或置信区间太宽时给出；其余为 OK。IE 的策略是不做定向、保留均匀份额。报告同时给出“IE 计为未触发”和“IE 计为触发”两种口径。

## 4. 结果（旧探针 v1 题集，CPU 已出；v2 题集待 GPU）

| 检测器 | 金标准 | 召回 | 误报率 | TP/FN/FP/TN | IE |
|---|---|---:|---:|---|---:|
| V1，原标签（Round 2 实际看到的） | G_drop（原标签金标准） | 1.00 | 0.10 | 5/0/1/9 | 0 |
| V1，原标签 | G_need（原标签金标准） | 0.38 | 0.50 | 5/8/1/1 | 0 |
| V1，修正标签 | G_drop | 1.00 | 0.25 | 3/0/3/9 | 0 |
| V1，修正标签 | G_need | **0.36** | 0.50 | 4/7/2/2 | 0 |
| V1，修正标签 | G_cum（n=6） | 1.00 | 0.33 | 3/0/1/2 | 0 |
| rule2，仅 DEGRADED | G_drop | 0.67 | **0.00** | 2/1/0/12 | 2 |
| rule2，全部状态，IE 计为未触发 | G_need | **0.82** | 0.50 | 9/2/2/2 | 2 |
| rule2，全部状态，IE 计为触发 | G_need | **1.00** | 0.50 | 11/0/2/2 | 2 |
| rule2 | G_cum（n=6） | 1.00 | 0.33 | 3/0/1/2 | 0 |

- 两个 IE 都出现在临界单元：A seed110 File和 C seed110 Database（中点 16/24，90% CI 为 [0.50, 0.80]）。
- G_need 的负例只有 4 个，误报率的分母非常小，不能当作稳定估计。
- 监测成本（v1，每次检查覆盖全部旧工具，A/C 平均）：60 题，输入约 34.1k token，生成约 3.2k token，约 35 秒（RTX 4060 Laptop，batch 32）。v2 每次检查 96 题（A）/ 64 题（C），预计约为 v1 的 1.3 倍；实测数字跑完后自动写入 `runs_ext_monitor/monitor_eval.json` 的 `costs.v2`。

**v2 探针集（已生成，`data_ext_monitor_v2/`，96 题）**：
- Database：filter-top 原句式 12 + 改写 12 + 带过滤的均值自然问法 8。
- File：在新目录、新文件上做 last-match 原句式 12 + 改写 12 + first-match 改写 8。标签按题意，填充词和查询词不重叠（Round 2 生成器里 'delta' 两者都会用到）。
- Python：显式中位数 8 + 原自然问法 8 + 带“排序/从小到大”触发词的改写 16（这类问法以前会诱发不存在的 `stats_sorted`）。

**泄露检查**：任务签名、工具调用签名（Database/Python）、中位数数值集合（排序后）都和 data_phase2、data_replay_study、data_round2 的全部划分不重叠；File 使用新的根目录 `mv2_*`。训练用的 `validate_probe_separation` 也已通过。

## 5. 对研究的含义

- Adaptive 在 C 场景“从未触发”是规则问题，不是探针看不见：C 里阶段内确实没有遗忘（Database 起点 0.23–0.33，终点 0.27–0.40），真正缺的是 Database 本来就不会，这是 DEFICIENT。
- 在线分配应该看“缺口”（gap = max(下降, τ − 当前水平)），而不只看“下降”。这个规则已经写在 `monitor_v2.target_weights`，在 E5 中验证。
- 论文里“File 不迁移”的表述要撤回，改成“target 内容的标签一致性决定复习是否有害”（C 场景 File 0.589 → 0.278 是直接证据）。

## 6. 局限

只有 15 个单元，种子少；阈值 τ=0.8、δ=0.10 是预先固定的；中点状态是从 Round 2 的共享前缀 `training_state.pt` 恢复 LoRA 参数得到的（会核对参数哈希，结果写进 `state_meta.json`）；G_cum 要等 ref checkpoint 的 GPU 评测。

## 7. 文件

- 代码（均为新增）：`fac_tinyagent/monitor_v2.py`、`ext_rescore.py`、`monitor_v2_data.py`、`monitor_v2_offline.py`
- 数据：`data_ext_monitor_v2/{file,database,python}.jsonl`、`manifest.json`
- 结果：`runs_ext_monitor/report.md`、`monitor_eval.json`、`eval/`（GPU 部分）
