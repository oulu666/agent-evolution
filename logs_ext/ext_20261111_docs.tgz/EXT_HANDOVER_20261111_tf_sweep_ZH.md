# 交接手册 · Monitor v2 验证 + Target Fraction 扫描链 · 2026-11-11

更新：2026-11-11 00:20（Asia/Shanghai，UTC+8）。通用环境（WSL、`.venv`、模型路径、功耗、PowerShell 坑）见 `HANDOVER_ENVIRONMENT_ZH.md` 与 `EXT_HANDOVER_20261110_ZH.md`。本轮结论见 `EXT_REPORT_20261111_monitor_ZH.md`，整体规划见 `RESEARCH_MATRIX_20261111_ZH.md`。

## 1. 现状

- 链 `scripts/run_tf_sweep_20261111.sh` 已于 2026-11-10 23:59:41 启动（runner pid 476，用 setsid + nohup 运行，不依赖会话在线）。
- CPU 部分已完成：v2 探针集生成、File 标签重判分、旧探针的 monitor 指标。
- 启动时显卡被用户的游戏（r5apex_dx12）占用，约 7.3GB / 90%。链在 `WAIT_GPU` 门控处等待：显存 < 3000MiB 且利用率 < 40%，连续 3 次（间隔 20 秒）才开始下一个 GPU 任务。**每个 GPU 任务开始前都会重新检查**，所以用户中途再开游戏时，链会在任务之间停下来等。
- 只新增，不改已有 `runs*`、`.venv`、conda `zxx`、`oulu\Small Agent`。已有代码一行未改。

## 2. 链的步骤（全部跳过已完成的结果）

| 步 | 内容 | 输出 | 估时（显卡空闲后） |
|---|---|---|---|
| 1 | `monitor_v2_data`：生成 v2 探针（已存在就跳过） | `data_ext_monitor_v2/` | 秒级 |
| 2 | `monitor_v2_offline --phase report`（CPU） | `runs_ext_monitor/report.md`、`monitor_eval.json` | 5 秒 |
| 3 | `monitor_v2_offline --phase gpu`：v2 探针跑 A/C × 3 种子的起点、中点（从 Round 2 前缀恢复）、none 终点、习得参考点；参考点另测 natural final | `runs_ext_monitor/eval/` | ≈30 min |
| 4 | 烟测：seed108 的 tf00 和 tf50，16 条新样本、1 epoch、每工具 4 条探针、每套评测 3 题，然后自动检查；通过后写 `runs_ext_tf_smoke/SMOKE_OK`，失败则 `ABORT` 并且不启动正式扫描 | `runs_ext_tf_smoke/` | ≈8 min |
| 5 | 正式扫描：按种子优先，seed108 的 tf00/25/50/75 → seed109 → seed110；每个 run 先训练再评测；每个种子结束后更新报告 | `runs_ext_tf/branches/`、`evaluation/`、`report.md`、`results.json` | ≈20 min/种子 |
| 6 | 可选 none 对照（同一前缀），3 个种子 | 同上 | ≈15 min |
| 7 | 最终报告：TF 报告 + monitor 报告（含 v2） | `runs_ext_tf/report.md`、`runs_ext_monitor/report.md` | 秒级 |

**全链估时**：显卡空闲后约 2 小时，其中 monitor ≈30 min、烟测 ≈8 min、12 个 TF run ≈65 min、none 对照 ≈15 min。等待游戏结束的时间另算。

TF 设置与 Round 2 A 一致：A 顺序 stage 3→4（Calendar 新，File/Database/Python 旧），同一个 Round 2 复习池和 target_ids，10% 新数据输入 token 预算，batch 1 / 梯度累积 8 / 2 epoch / lr 1e-4，复习只在后半段，固定 target 族权重各 1/3，`mode=targeted`，`target_fraction ∈ {0, .25, .5, .75}`（tf00 等价于 uniform）。唯一的区别是探针换成 v2，所以生成了新的共享前缀 `runs_ext_tf/prefixes/A_seed*`。每个种子第一个 run（tf00）负责创建前缀，其余 run 复用。

每个 run 记录（`runs_ext_tf/results.json`）：
- natural final：修正判分和原判分两种口径
- 历史测试：4 个工具
- Calendar（新工具）
- v2 探针终点分
- 实际复习 token、实际 target 比例、target 样本数
- 分支实际耗时和参考耗时
- 起点/中点的探针分

## 3. 查看、停止、续跑

```bash
cd "/mnt/c/Users/Egret/Desktop/oulu/Agent Self-Evolution/fac_tinyagent"
tail -n 30 logs_ext/tf_sweep_20261111.status      # START/DONE/FAIL/WAIT_GPU/ALL_DONE
tail -n 50 logs_ext/tf_sweep_20261111.log
ps -p "$(cat logs_ext/tf_sweep_20261111.pid)" -o pid,etime,cmd
bash scripts/stop_tf_sweep.sh                       # 一键停止：写 stop 旗标并结束进程组
rm -f logs_ext/tf_sweep_20261111.stop && bash scripts/launch_tf_sweep_20261111.sh   # 续跑
```

在 PowerShell 里：

```powershell
wsl.exe -d Ubuntu -- bash -lc 'tail -n 30 "/mnt/c/Users/Egret/Desktop/oulu/Agent Self-Evolution/fac_tinyagent/logs_ext/tf_sweep_20261111.status"'
wsl.exe -d Ubuntu -- bash -lc 'bash "/mnt/c/Users/Egret/Desktop/oulu/Agent Self-Evolution/fac_tinyagent/scripts/stop_tf_sweep.sh"'
```

- 中断在训练中途：下次启动时，没写出 `train_summary.json` 的分支目录会被改名为 `*_partial_<时间戳>` 放到一边，然后重训；已完成的分支和评测会跳过。
- 门控参数可以用环境变量调整，例如 `GATE_MEM_MIB=3500`。只跑部分内容：`TF_SEEDS="20261108" TF_ARMS="tf00 tf50"`；跳过 none 对照：`TF_SKIP_NONE=1`；跳过 monitor：`TF_SKIP_MONITOR=1`。
- 单独重做报告（CPU）：`.venv/bin/python -m fac_tinyagent.ext_tf_sweep --phase report`，以及 `.venv/bin/python -m fac_tinyagent.monitor_v2_offline --phase report`。

## 4. 新增文件

- 代码：
  - `fac_tinyagent/monitor_v2.py`：判定规则
  - `fac_tinyagent/ext_rescore.py`：File 重判分
  - `fac_tinyagent/monitor_v2_data.py`：v2 探针生成
  - `fac_tinyagent/monitor_v2_offline.py`：离线验证
  - `fac_tinyagent/ext_tf_sweep.py`：TF 扫描的训练、评测、报告
- 脚本：`scripts/run_tf_sweep_20261111.sh`、`scripts/launch_tf_sweep_20261111.sh`、`scripts/stop_tf_sweep.sh`
- 数据和结果：`data_ext_monitor_v2/`、`runs_ext_monitor/`、`runs_ext_tf/`、`runs_ext_tf_smoke/`
- 日志：`logs_ext/tf_sweep_20261111.{log,status,pid}`、`logs_ext/ext_20261111_code.tgz`、`logs_ext/ext_20261111_patch1.tgz`（代码投放包）
- 文档：`RESEARCH_MATRIX_20261111_ZH.md`、`EXT_REPORT_20261111_monitor_ZH.md`、本文件

## 5. 已知问题与注意事项

1. TF 扫描沿用 Round 2 的 target 池，其中 16 条 File target 行带着“整列表”错误标签。tf 越大，File 修正分可能越低，这是已知混杂因素，由研究矩阵 E4 拆开。读结果时以修正口径的 Database/Python 为主，单独看 File。
2. 复习插入位置 `common_replay_positions` 取三种计划的最小样本数，因 tf 不同而可能略有差异。实际位置数记录在每个 run 的 `replay_positions` 字段。
3. 起点分直接引用 Round 2 的 start 评测（同一个 stage_03 adapter、同一评测协议，只读），不重测。
4. `replay_train.py` 的 adaptive 仍是 v1 规则；v2 自适应在 E5 中另写新模块实现，不改旧文件。
5. C 盘剩余约 73GB；本链新增约 0.5GB。
